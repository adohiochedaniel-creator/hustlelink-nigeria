# HustleLink Nigeria Web

Mobile-first React/Vite web version. No phone OTP.

## Run
npm install
npm run dev

## Supabase
Copy .env.example to .env and add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY (public/anon/publishable key only). Never put service_role/secret in the browser.

Run `supabase/migrations/001_hustlelink_web.sql` in the Supabase SQL Editor. It safely fixes the previous `jobs.featured does not exist` mismatch.

## Paystack
Set VITE_PAYSTACK_PUBLIC_KEY in the web host. Set PAYSTACK_SECRET_KEY only as a Supabase Edge Function secret. Deploy the included `paystack-initiate` and `paystack-verify` functions. Verify transactions server-side before recording premium/featured/payment success.

## Publish
Build with `npm run build`; output is `dist/`. Cloudflare Pages can use build command `npm run build` and output `dist`.

Social links: Instagram and TikTok are included. Facebook remains configurable because the exact page URL was not supplied.
